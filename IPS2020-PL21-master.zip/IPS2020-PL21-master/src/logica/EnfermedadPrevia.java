/**
 * 
 */
package logica;

/**
 * @author Mar�a
 *
 */
public class EnfermedadPrevia {

private String nombreEnfermPrev;
	
	
	public EnfermedadPrevia(String nombreEnfermPrev) {
		this.nombreEnfermPrev = nombreEnfermPrev;
	}
	
	
	public String getNombreEnfermPrev() {
		return nombreEnfermPrev;
	}
	
	
	public void setNombreEnfermPrev(String nombreEnfermPrev) {
		this.nombreEnfermPrev = nombreEnfermPrev;
	}
}
